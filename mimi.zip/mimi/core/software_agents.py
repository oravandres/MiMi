"""Software Engineer AI Super Agent implementation for MiMi."""

from typing import Any, Dict, List, Optional, Union, Callable
import json
import os
from datetime import datetime
from pathlib import Path
import re

from pydantic import BaseModel, Field, ConfigDict

from mimi.core.agent import Agent
from mimi.utils.logger import agent_log, logger
from mimi.utils.output_manager import (
    create_output_directory,
    process_implementation_output,
    save_documentation, 
    save_code_blocks_from_text,
    save_project_metadata,
    create_or_update_project_log
)

# Add a global variable to track the project directory across agents
_project_directory: Optional[Path] = None

def get_project_directory(project_title: str) -> Path:
    """Get the project directory, creating it if it doesn't exist.
    
    Args:
        project_title: The title of the project.
        
    Returns:
        The path to the project directory.
    """
    global _project_directory
    if _project_directory is None:
        _project_directory = create_output_directory(project_title)
    return _project_directory


class ResearchAnalystAgent(Agent):
    """Agent that analyzes project requirements and prepares specifications."""
    
    def execute(self, task_input: Any) -> Any:
        """Analyze project requirements and prepare detailed specifications.
        
        Args:
            task_input: A dictionary containing project requirements.
            
        Returns:
            A dictionary with detailed project specifications.
        """
        agent_log(
            self.name,
            "execute",
            f"Analyzing project requirements: {str(task_input)}"
        )
        
        # Extract requirements from input
        requirements = task_input.get("project_requirements", task_input)
        logger.debug(f"Extracted requirements: {str(requirements)[:200]}...")
        
        # Create system prompt for analyzing requirements
        system_prompt = """
        You are an expert Research Analyst for software projects. Your task is to:
        1. Analyze the given project requirements carefully
        2. Break down the requirements into functional and non-functional components
        3. Identify technical challenges and potential solutions
        4. Prepare a detailed specification document for the architect to use
        
        Provide a comprehensive analysis that will help the architect design the system.
        """
        
        # Construct the prompt for the model
        prompt = f"""
        # Project Requirements
        {requirements}
        
        # Task
        Analyze these requirements and prepare detailed specifications including:
        - Project overview and goals
        - Functional requirements (detailed)
        - Non-functional requirements (performance, security, scalability, etc.)
        - Technical challenges and potential approaches
        - Required technologies and components
        - Any assumptions or constraints
        
        Format your response as a structured specification document.
        """
        
        # Get model client
        client = self.get_model_client()
        logger.debug(f"Got model client: {client.__class__.__name__}")
        
        try:
            # Generate specifications using the model
            logger.debug("Calling model generate() method...")
            response = client.generate(prompt, system_prompt=system_prompt)
            logger.debug(f"Received response from model, length: {len(response)}")
            
            # Extract project title from the response or use a default
            project_title = "Task Management Application"
            title_match = re.search(r'#\s+(.+?)\n', response)
            if title_match:
                project_title = title_match.group(1).strip()
                logger.debug(f"Extracted project title: {project_title}")
            else:
                logger.debug(f"Could not extract project title, using default: {project_title}")
            
            # Get or create project directory
            logger.debug(f"Creating project directory for title: {project_title}")
            project_dir = get_project_directory(project_title)
            
            # Save the specifications to the project directory
            specs_path = project_dir / "docs" / "specifications.md"
            specs_path.parent.mkdir(exist_ok=True)
            logger.debug(f"Writing specifications to: {specs_path}")
            with open(specs_path, 'w') as f:
                f.write(response)
            
            # Save the original requirements
            req_path = project_dir / "docs" / "requirements.md"
            logger.debug(f"Writing requirements to: {req_path}")
            with open(req_path, 'w') as f:
                f.write(str(requirements))
            
            # Save project metadata
            metadata = {
                "project_title": project_title,
                "timestamp": datetime.now().isoformat(),
                "analyst": self.name,
                "specifications_path": str(specs_path),
                "requirements_path": str(req_path)
            }
            logger.debug(f"Saving project metadata: {json.dumps(metadata)[:200]}...")
            save_project_metadata(project_dir, metadata)
            
            # Create project log
            log_details = {
                "specifications_file": str(specs_path),
                "requirements_file": str(req_path),
                "project_title": project_title
            }
            logger.debug("Creating project log file...")
            create_or_update_project_log(
                project_dir,
                "requirements-analysis",
                self.name,
                "Analyzed requirements and created specifications",
                log_details
            )
            
            # Log to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="requirements-analysis",
                input_summary=str(requirements)[:200] + "..." if len(str(requirements)) > 200 else str(requirements),
                output_summary=f"Generated specifications document ({len(response)} chars)",
                details={
                    "project_title": project_title,
                    "specifications_file": str(specs_path),
                    "requirements_file": str(req_path)
                }
            )
            
            # Structure the output
            specifications = {
                "timestamp": datetime.now().isoformat(),
                "analyst": self.name,
                "project_specifications": response,
                "original_requirements": requirements,
                "project_title": project_title,
                "project_dir": str(project_dir)
            }
            
            agent_log(
                self.name,
                "execute",
                f"Successfully generated project specifications and saved to {specs_path}"
            )
            
            return specifications
        except Exception as e:
            error_msg = f"Error in ResearchAnalystAgent: {str(e)}"
            logger.error(error_msg)
            agent_log(self.name, "error", error_msg)
            
            # Log the error to project log if we have a project directory
            if 'project_dir' in locals():
                error_details = {"error_message": str(e)}
                create_or_update_project_log(
                    project_dir,
                    "error",
                    self.name,
                    "Error during requirements analysis",
                    error_details
                )
                
                # Log error to agent.log.md
                self.log_to_agent_file(
                    project_dir=project_dir,
                    action_type="error",
                    input_summary=str(requirements)[:100] + "..." if len(str(requirements)) > 100 else str(requirements),
                    output_summary=f"Error: {str(e)}",
                    details={"error_type": type(e).__name__}
                )
            
            raise


class ArchitectAgent(Agent):
    """Agent that creates architecture plans and divides work into tasks."""
    
    def execute(self, task_input: Any) -> Any:
        """Create architecture design or divide work into tasks.
        
        Args:
            task_input: A dictionary containing specifications or architecture plan.
            
        Returns:
            A dictionary with an architecture plan or engineering tasks.
        """
        agent_log(
            self.name,
            "execute",
            f"Creating architecture or task plan"
        )
        
        # Determine the task type based on the input
        if isinstance(task_input, dict) and "stage" in task_input:
            stage = task_input["stage"]
            
            # Execute the appropriate method based on stage
            if stage == "architecture":
                result = self._create_architecture(task_input)
            elif stage == "task_planning":
                result = self._create_task_plan(task_input)
            else:
                error_msg = f"Unknown stage: {stage}"
                agent_log(self.name, "error", error_msg)
                raise ValueError(error_msg)
        else:
            # Default to architecture creation if no stage specified
            result = self._create_architecture(task_input)
        
        return result

    def _create_architecture(self, task_input: Dict[str, Any]) -> Dict[str, Any]:
        """Create an architecture plan based on project specifications.
        
        Args:
            task_input: A dictionary containing project specifications.
            
        Returns:
            A dictionary with the architecture plan.
        """
        agent_log(
            self.name,
            "execute",
            f"Creating architecture plan"
        )
        
        # Extract specifications and other metadata
        specifications = task_input.get("project_specifications", "")
        project_title = task_input.get("project_title", "Unknown Project")
        project_dir_str = task_input.get("project_dir", None)
        
        if project_dir_str:
            project_dir = Path(project_dir_str)
        else:
            logger.warning(f"Project directory not provided, creating new one for {project_title}")
            project_dir = get_project_directory(project_title)
        
        # Create system prompt for architecture design
        system_prompt = """
        You are an expert Solution Architect designing software systems. Your task is to:
        1. Create a comprehensive architecture plan based on the specifications
        2. Define system components and how they interact
        3. Select appropriate technologies and frameworks
        4. Consider scalability, performance, and security in your design
        
        Provide a detailed architecture document that will guide the implementation.
        """
        
        # Construct the prompt for the model
        prompt = f"""
        # Project Specifications
        {specifications}
        
        # Task
        Create a detailed architecture plan including:
        - System overview and architecture style (e.g., microservices, monolith, serverless)
        - Component diagram showing major parts of the system
        - Technology stack selection with justification
        - Data model and storage approach
        - API design and communication patterns
        - Security considerations
        - Deployment strategy
        
        Format your response as a structured architecture document.
        """
        
        # Get model client
        client = self.get_model_client()
        
        try:
            # Generate architecture plan using the model
            response = client.generate(prompt, system_prompt=system_prompt)
            
            # Save the architecture plan to the project directory
            arch_path = project_dir / "docs" / "architecture.md"
            arch_path.parent.mkdir(exist_ok=True)
            with open(arch_path, 'w') as f:
                f.write(response)
            
            # Create project log
            log_details = {
                "architecture_file": str(arch_path),
                "project_title": project_title
            }
            create_or_update_project_log(
                project_dir,
                "architecture-design",
                self.name,
                "Created architecture plan",
                log_details
            )
            
            # Log to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="architecture-design",
                input_summary=f"Project specifications for {project_title}",
                output_summary=f"Generated architecture plan ({len(response)} chars)",
                details={
                    "architecture_file": str(arch_path)
                }
            )
            
            # Structure the output
            architecture = {
                "timestamp": datetime.now().isoformat(),
                "architect": self.name,
                "architecture_plan": response,
                "project_title": project_title,
                "project_dir": str(project_dir),
                "stage": "task_planning"  # Set next stage
            }
            
            agent_log(
                self.name,
                "execute",
                f"Successfully generated architecture plan and saved to {arch_path}"
            )
            
            return architecture
        except Exception as e:
            error_msg = f"Error in ArchitectAgent (architecture): {str(e)}"
            logger.error(error_msg)
            agent_log(self.name, "error", error_msg)
            
            # Log the error to project log
            error_details = {"error_message": str(e)}
            create_or_update_project_log(
                project_dir,
                "error",
                self.name,
                "Error during architecture design",
                error_details
            )
            
            # Log error to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="error",
                input_summary=f"Project specifications for {project_title}",
                output_summary=f"Error: {str(e)}",
                details={"error_type": type(e).__name__}
            )
            
            raise

    def _create_task_plan(self, task_input: Dict[str, Any]) -> Dict[str, Any]:
        """Create a task plan based on the architecture.
        
        Args:
            task_input: A dictionary containing the architecture plan.
            
        Returns:
            A dictionary with tasks for each engineer.
        """
        agent_log(
            self.name,
            "execute",
            f"Creating task plan"
        )
        
        # Extract architecture and other metadata
        architecture_plan = task_input.get("architecture_plan", "")
        project_title = task_input.get("project_title", "Unknown Project")
        project_dir_str = task_input.get("project_dir", None)
        
        if project_dir_str:
            project_dir = Path(project_dir_str)
        else:
            logger.warning(f"Project directory not provided, creating new one for {project_title}")
            project_dir = get_project_directory(project_title)
        
        # Create system prompt for task planning
        system_prompt = """
        You are an expert Project Manager dividing work into tasks. Your task is to:
        1. Analyze the architecture plan
        2. Break down the implementation into specific tasks
        3. Assign tasks to appropriate engineering roles (backend, frontend, infrastructure)
        4. Prioritize tasks based on dependencies
        
        Provide a detailed task plan that will guide the engineering team's implementation.
        """
        
        # Construct the prompt for the model
        prompt = f"""
        # Architecture Plan
        {architecture_plan}
        
        # Task
        Create a detailed implementation task plan including:
        - Backend tasks with specific components to implement
        - Frontend tasks with specific components to implement
        - Infrastructure tasks with specific components to implement
        - Priority order and dependencies between tasks
        - Acceptance criteria for each task
        
        Organize tasks by role (backend, frontend, infrastructure).
        """
        
        # Get model client
        client = self.get_model_client()
        
        try:
            # Generate task plan using the model
            response = client.generate(prompt, system_prompt=system_prompt)
            
            # Save the task plan to the project directory
            tasks_path = project_dir / "docs" / "tasks.md"
            tasks_path.parent.mkdir(exist_ok=True)
            with open(tasks_path, 'w') as f:
                f.write(response)
            
            # Create project log
            log_details = {
                "tasks_file": str(tasks_path),
                "project_title": project_title
            }
            create_or_update_project_log(
                project_dir,
                "task-planning",
                self.name,
                "Created implementation tasks",
                log_details
            )
            
            # Log to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="task-planning",
                input_summary=f"Architecture plan for {project_title}",
                output_summary=f"Generated task plan ({len(response)} chars)",
                details={
                    "tasks_file": str(tasks_path)
                }
            )
            
            # Structure the output for each engineer
            task_plan = {
                "timestamp": datetime.now().isoformat(),
                "architect": self.name,
                "task_plan": response,
                "project_title": project_title,
                "project_dir": str(project_dir),
                "engineer_tasks": {
                    "backend": self._extract_backend_tasks(response),
                    "frontend": self._extract_frontend_tasks(response),
                    "infrastructure": self._extract_infrastructure_tasks(response)
                }
            }
            
            agent_log(
                self.name,
                "execute",
                f"Successfully generated task plan and saved to {tasks_path}"
            )
            
            return task_plan
        except Exception as e:
            error_msg = f"Error in ArchitectAgent (task planning): {str(e)}"
            logger.error(error_msg)
            agent_log(self.name, "error", error_msg)
            
            # Log the error to project log
            error_details = {"error_message": str(e)}
            create_or_update_project_log(
                project_dir,
                "error",
                self.name,
                "Error during task planning",
                error_details
            )
            
            # Log error to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="error",
                input_summary=f"Architecture plan for {project_title}",
                output_summary=f"Error: {str(e)}",
                details={"error_type": type(e).__name__}
            )
            
            raise
            
    def _extract_backend_tasks(self, task_plan: str) -> str:
        """Extract backend tasks from the task plan.
        
        Args:
            task_plan: The full task plan.
            
        Returns:
            The backend-specific tasks.
        """
        # Simple extraction based on headers or sections
        backend_section = ""
        in_backend = False
        
        for line in task_plan.split('\n'):
            if re.search(r'#+ .*backend', line, re.IGNORECASE):
                in_backend = True
                backend_section += line + '\n'
            elif in_backend and re.search(r'#+ .*frontend|#+ .*infrastructure', line, re.IGNORECASE):
                in_backend = False
            elif in_backend:
                backend_section += line + '\n'
        
        return backend_section if backend_section else task_plan

    def _extract_frontend_tasks(self, task_plan: str) -> str:
        """Extract frontend tasks from the task plan.
        
        Args:
            task_plan: The full task plan.
            
        Returns:
            The frontend-specific tasks.
        """
        # Simple extraction based on headers or sections
        frontend_section = ""
        in_frontend = False
        
        for line in task_plan.split('\n'):
            if re.search(r'#+ .*frontend', line, re.IGNORECASE):
                in_frontend = True
                frontend_section += line + '\n'
            elif in_frontend and re.search(r'#+ .*backend|#+ .*infrastructure', line, re.IGNORECASE):
                in_frontend = False
            elif in_frontend:
                frontend_section += line + '\n'
        
        return frontend_section if frontend_section else task_plan

    def _extract_infrastructure_tasks(self, task_plan: str) -> str:
        """Extract infrastructure tasks from the task plan.
        
        Args:
            task_plan: The full task plan.
            
        Returns:
            The infrastructure-specific tasks.
        """
        # Simple extraction based on headers or sections
        infra_section = ""
        in_infra = False
        
        for line in task_plan.split('\n'):
            if re.search(r'#+ .*infrastructure|#+ .*devops', line, re.IGNORECASE):
                in_infra = True
                infra_section += line + '\n'
            elif in_infra and re.search(r'#+ .*backend|#+ .*frontend', line, re.IGNORECASE):
                in_infra = False
            elif in_infra:
                infra_section += line + '\n'
        
        return infra_section if infra_section else task_plan


class SoftwareEngineerAgent(Agent):
    """Agent that implements software components according to the architecture plan."""
    
    specialty: str = Field("backend", description="Engineer's specialty (backend, frontend, or infrastructure)")
    
    def execute(self, task_input: Any) -> Any:
        """Implement software components according to the task plan.
        
        Args:
            task_input: A dictionary containing the task plan and project information.
            
        Returns:
            A dictionary with the implemented components.
        """
        agent_log(
            self.name,
            "execute",
            f"Implementing {self.specialty} components"
        )
        
        # Log the input type for easier debugging
        input_type = type(task_input).__name__
        logger.debug(f"SoftwareEngineerAgent({self.specialty}) received input of type: {input_type}")
        
        # Extract tasks and project information
        project_title = "Unknown Project"
        project_dir_str = None
        
        if isinstance(task_input, dict):
            project_title = task_input.get("project_title", "Unknown Project")
            project_dir_str = task_input.get("project_dir", None)
            
            # Log the keys for debugging
            logger.debug(f"SoftwareEngineerAgent input keys: {list(task_input.keys())}")
        elif isinstance(task_input, str) and len(task_input) > 0:
            # If we get a string directly, assume it's a revision plan
            logger.info("SoftwareEngineerAgent received string input, treating as revision plan")
            project_dir_str = get_project_directory(project_title)
            return self._implement_revisions(task_input, project_dir_str, project_title)
        
        if project_dir_str:
            project_dir = Path(project_dir_str)
        else:
            logger.warning(f"Project directory not provided, creating new one for {project_title}")
            project_dir = get_project_directory(project_title)
        
        agent_log(
            self.name,
            "execute",
            f"Implementing {self.specialty} components based on tasks"
        )
        
        try:
            # Determine the action based on input
            if isinstance(task_input, dict):
                # Log key detection for debugging complex inputs
                revision_keys = [k for k in task_input.keys() if 'revision' in k.lower()]
                if revision_keys:
                    logger.debug(f"Found revision-related keys: {revision_keys}")
                
                if "task_plan" in task_input:
                    if "engineer_tasks" in task_input:
                        tasks = task_input["engineer_tasks"].get(self.specialty, task_input["task_plan"])
                    else:
                        tasks = task_input["task_plan"]
                    return self._implement_components(tasks, project_dir, project_title)
                elif "revision_plan" in task_input:
                    revision_plan = task_input["revision_plan"]
                    return self._implement_revisions(revision_plan, project_dir, project_title)
                elif "revisions" in task_input:
                    # Handle case where revision is under a different key name
                    revisions = task_input["revisions"]
                    return self._implement_revisions(revisions, project_dir, project_title)
                elif "architecture_plan" in task_input:
                    # Special case for when revision_plan is contained in the architecture_plan
                    architecture_plan = task_input["architecture_plan"]
                    return self._implement_revisions(architecture_plan, project_dir, project_title)
                elif "test_results" in task_input:
                    # Get test results, which could be a string or a complex object
                    test_results = task_input["test_results"]
                    if isinstance(test_results, dict):
                        # Extract the actual test results string
                        test_results_str = test_results.get("test_results", str(test_results))
                        # If we find an "error" status, use the message
                        if test_results.get("status") == "error":
                            test_results_str = test_results.get("message", test_results_str)
                    else:
                        test_results_str = str(test_results)
                    return self._fix_bugs(test_results_str, project_dir, project_title)
                elif "components" in task_input:
                    return self._integrate_components(task_input["components"], project_dir, project_title)
                # Special case for when we just get a testing result directly
                elif "status" in task_input and task_input.get("status") == "error" and "message" in task_input:
                    test_results_str = task_input.get("message", "Unknown error")
                    return self._fix_bugs(test_results_str, project_dir, project_title)
                # Handle case when project_review is passed from the reviewer and contains revision info
                elif "project_review" in task_input:
                    project_review = task_input["project_review"]
                    return self._implement_revisions(project_review, project_dir, project_title)
                # Check if any key contains revision info as a fallback
                else:
                    # Look for any key that might contain revision information
                    for key, value in task_input.items():
                        if isinstance(value, str) and len(value) > 100:
                            # If we find a reasonably sized string value, check if it looks like a revision plan
                            if "revision" in key.lower() or "review" in key.lower() or "implement" in key.lower():
                                logger.info(f"Using key '{key}' as revision plan")
                                return self._implement_revisions(value, project_dir, project_title)
                            elif "fix" in key.lower() or "bug" in key.lower() or "test" in key.lower():
                                logger.info(f"Using key '{key}' as test results")
                                return self._fix_bugs(value, project_dir, project_title)
            
            # If no specific input format is recognized, but we have project information,
            # check for any revision documents in the project directory and use them
            try:
                # Check multiple possible revision document locations
                revision_files = [
                    project_dir / "docs" / "project_review.md",
                    project_dir / "docs" / "revisions.md",
                    project_dir / "docs" / "review.md",
                    project_dir / "project_review.md"
                ]
                
                for rev_file in revision_files:
                    if rev_file.exists():
                        with open(rev_file, 'r') as f:
                            project_review = f.read()
                        logger.info(f"Using {rev_file.name} for revisions")
                        return self._implement_revisions(project_review, project_dir, project_title)
                
                # If we're here, we should check if there's a README or other documentation that might contain revision info
                potential_docs = [
                    project_dir / "README.md",
                    project_dir / "docs" / "README.md"
                ]
                
                for doc_file in potential_docs:
                    if doc_file.exists():
                        with open(doc_file, 'r') as f:
                            doc_content = f.read()
                        # Check if this document contains revision-like content
                        if "revision" in doc_content.lower() or "improvements" in doc_content.lower() or "changes" in doc_content.lower():
                            logger.info(f"Using {doc_file.name} for revisions")
                            return self._implement_revisions(doc_content, project_dir, project_title)
            except Exception as doc_error:
                logger.warning(f"Failed to read project review document: {str(doc_error)}")
            
            # If we get here, we couldn't figure out what to do
            # Add detailed logging of the input to help diagnose the issue
            input_keys = str(task_input.keys()) if isinstance(task_input, dict) else "N/A"
            input_sample = str(task_input)[:200] + "..." if len(str(task_input)) > 200 else str(task_input)
            
            error_msg = f"Unrecognized input format for SoftwareEngineerAgent. Type: {input_type}, Keys: {input_keys}"
            agent_log(self.name, "error", error_msg)
            logger.error(f"Input sample: {input_sample}")
            
            # Log the error to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type="error",
                input_summary="Invalid input structure",
                output_summary=error_msg,
                details={
                    "error_type": "InputError",
                    "input_type": input_type,
                    "input_keys": input_keys,
                    "input_sample": input_sample
                }
            )
            
            raise ValueError(error_msg)
        except Exception as e:
            error_msg = f"Error in SoftwareEngineerAgent ({self.specialty}): {str(e)}"
            logger.error(error_msg)
            agent_log(self.name, "error", error_msg)
            raise

    def _implement_components(self, tasks: str, project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Implement components based on the task plan.
        
        Args:
            tasks: Task descriptions for this engineer's specialty.
            project_dir: Path to the project directory.
            project_title: Title of the project.
            
        Returns:
            A dictionary with the implemented components.
        """
        agent_log(
            self.name,
            "execute",
            f"Implementing {self.specialty} components based on tasks"
        )
        
        # Determine the role-specific system prompt
        if self.specialty == "backend":
            system_prompt = """
            You are an expert Backend Engineer implementing server-side components. Your task is to:
            1. Create robust, maintainable backend code according to the task requirements
            2. Implement RESTful APIs, database models, and business logic
            3. Follow best practices for security, error handling, and performance
            4. Document your code and API endpoints
            
            Provide clear, well-structured implementation with proper error handling.
            
            IMPORTANT: When referencing URLs, always use the full form with protocol (http:// or https://), 
            never use //hostname notation as this might be confused with file paths. Example: use 
            "http://localhost:8080" and not "//localhost:8080".
            """
        elif self.specialty == "frontend":
            system_prompt = """
            You are an expert Frontend Engineer implementing client-side components. Your task is to:
            1. Create clean, modular, and maintainable frontend code
            2. Implement responsive user interfaces with good UX practices
            3. Ensure proper data validation and error handling
            4. Document your components and their usage
            
            Provide clear, well-structured implementation with a focus on user experience.
            
            IMPORTANT: When referencing URLs, always use the full form with protocol (http:// or https://), 
            never use //hostname notation as this might be confused with file paths. Example: use 
            "http://localhost:8080" and not "//localhost:8080".
            """
        elif self.specialty == "infrastructure":
            system_prompt = """
            You are an expert Infrastructure Engineer implementing deployment and CI/CD systems. Your task is to:
            1. Create robust configuration for deployment, monitoring, and scaling
            2. Set up CI/CD pipelines for automated testing and deployment
            3. Implement security best practices for infrastructure components
            4. Document your configuration and usage instructions
            
            Provide clear, well-structured implementation with a focus on reliability and security.
            """
        else:
            system_prompt = """
            You are an expert Software Engineer implementing components. Your task is to:
            1. Create clean, maintainable code according to the task requirements
            2. Follow best practices for your area of specialty
            3. Ensure proper error handling and validation
            4. Document your code and its usage
            
            Provide clear, well-structured implementation.
            """
        
        # Construct the prompt for the model
        prompt = f"""
        # {self.specialty.capitalize()} Tasks
        {tasks}
        
        # Project Title
        {project_title}
        
        # Task
        Implement the {self.specialty} components described in the tasks above. For each component:
        1. Provide the full implementation code (in Markdown code blocks)
        2. Include any necessary configuration files
        3. Add brief comments explaining your implementation decisions
        4. Provide usage examples for key components
        
        Format your code with proper indentation and structure. Include filename at the beginning of each code block.
        """
        
        # Get model client
        client = self.get_model_client()
        
        try:
            # Generate implementation
            logger.debug(f"Generating {self.specialty} implementation...")
            response = client.generate(prompt, system_prompt=system_prompt)
            logger.debug(f"Generated implementation, length: {len(response)}")
            
            # Process and save the implementation
            logger.debug(f"Processing implementation output...")
            result = process_implementation_output(project_dir, self.specialty, response)
            logger.debug(f"Saved {len(result.get('saved_files', []))} files")
            
            # Create project log
            log_details = {
                "implementation_doc": result.get("implementation_doc", ""),
                "component_type": self.specialty,
                "saved_files": len(result.get("saved_files", [])),
                "project_title": project_title
            }
            create_or_update_project_log(
                project_dir,
                f"{self.specialty}-implementation",
                self.name,
                f"Implemented {self.specialty} components",
                log_details
            )
            
            # Log to agent.log.md
            self.log_to_agent_file(
                project_dir=project_dir,
                action_type=f"{self.specialty}-implementation",
                input_summary=f"{self.specialty.capitalize()} tasks for {project_title}",
                output_summary=f"Generated {len(result.get('saved_files', []))} {self.specialty} component files",
                details={
                    "implementation_doc": result.get("implementation_doc", ""),
                    "files": [os.path.basename(f) for f in result.get("saved_files", [])][:5]
                }
            )
            
            # Structure the output
            implementation = {
                "timestamp": datetime.now().isoformat(),
                "engineer": self.name,
                "specialty": self.specialty,
                "implementation": response,
                "files": result.get("saved_files", []),
                "project_title": project_title,
                "project_dir": str(project_dir)
            }
            
            agent_log(
                self.name,
                "execute",
                f"Successfully implemented {self.specialty} components"
            )
            
            return implementation
        except Exception as e:
            error_msg = f"Error in SoftwareEngineerAgent ({self.specialty}): {str(e)}"
            logger.error(error_msg)
            agent_log(self.name, "error", error_msg)
            
            # Check for common error patterns and attempt recovery
            recovered_implementation = None
            
            # Check for permission denied on URLs (common error with //localhost paths)
            if isinstance(e, PermissionError) and "//" in str(e):
                logger.info("Attempting to recover from URL path error...")
                try:
                    # Extract the problematic URL from the error
                    import re
                    url_match = re.search(r"'(//[^']*)'", str(e))
                    if url_match:
                        bad_path = url_match.group(1)
                        fixed_url = "http:" + bad_path
                        logger.info(f"Found bad URL format: {bad_path}, fixing to {fixed_url}")
                        
                        # Modified system prompt to emphasize URL format
                        fixed_system_prompt = system_prompt + f"""
                        
                        CRITICAL FIX REQUIRED: In your previous attempt, you incorrectly used '{bad_path}' 
                        which was treated as a file path. Always use full URLs with protocol like '{fixed_url}'.
                        """
                        
                        # Regenerate implementation with fixed prompt
                        agent_log(self.name, "recovery", f"Retrying with fixed URL format: {fixed_url}")
                        
                        # Get model client
                        client = self.get_model_client()
                        
                        # Generate implementation with fixed prompt
                        logger.debug(f"Regenerating {self.specialty} implementation with URL fix...")
                        response = client.generate(prompt, system_prompt=fixed_system_prompt)
                        
                        # Process and save the implementation
                        logger.debug(f"Processing regenerated implementation output...")
                        result = process_implementation_output(project_dir, self.specialty, response)
                        
                        # Log the recovery
                        recovery_details = {
                            "original_error": str(e),
                            "recovery_action": f"Fixed URL format from '{bad_path}' to '{fixed_url}'",
                            "implementation_doc": result.get("implementation_doc", ""),
                            "component_type": self.specialty,
                            "saved_files": len(result.get("saved_files", [])),
                            "project_title": project_title
                        }
                        
                        create_or_update_project_log(
                            project_dir,
                            "recovery",
                            self.name,
                            f"Recovered from URL format error in {self.specialty} implementation",
                            recovery_details
                        )
                        
                        # Log recovery to agent.log.md
                        self.log_to_agent_file(
                            project_dir=project_dir,
                            action_type="error-recovery",
                            input_summary=f"{self.specialty.capitalize()} tasks for {project_title}",
                            output_summary=f"Recovered from URL format error: '{bad_path}' → '{fixed_url}'",
                            details=recovery_details
                        )
                        
                        # Return recovered implementation
                        recovered_implementation = {
                            "timestamp": datetime.now().isoformat(),
                            "engineer": self.name,
                            "specialty": self.specialty,
                            "implementation": response,
                            "files": result.get("saved_files", []),
                            "project_title": project_title,
                            "project_dir": str(project_dir),
                            "recovery_note": f"Automatically recovered from URL path error: '{bad_path}' → '{fixed_url}'"
                        }
                        
                        agent_log(
                            self.name,
                            "execute",
                            f"Successfully recovered and implemented {self.specialty} components"
                        )
                except Exception as recovery_error:
                    logger.error(f"Recovery attempt failed: {str(recovery_error)}")
                    agent_log(self.name, "error", f"Recovery attempt failed: {str(recovery_error)}")
                    
                    # Log the failed recovery attempt
                    self.log_to_agent_file(
                        project_dir=project_dir,
                        action_type="failed-recovery",
                        input_summary=f"{self.specialty.capitalize()} tasks for {project_title}",
                        output_summary=f"Recovery attempt failed: {str(recovery_error)}",
                        details={
                            "original_error": str(e),
                            "recovery_error": str(recovery_error)
                        }
                    )
            
            # Log the original error to project log if no recovery
            if recovered_implementation is None:
                error_details = {"error_message": str(e)}
                create_or_update_project_log(
                    project_dir,
                    "error",
                    self.name,
                    f"Error during {self.specialty} implementation",
                    error_details
                )
                
                # Log error to agent.log.md
                self.log_to_agent_file(
                    project_dir=project_dir,
                    action_type="error",
                    input_summary=f"{self.specialty.capitalize()} tasks for {project_title}",
                    output_summary=f"Error: {str(e)}",
                    details={"error_type": type(e).__name__}
                )
                
                raise
            
            return recovered_implementation

    def _implement_revisions(self, revision_plan: str, project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Implement revisions based on revision plan."""
        # Log what we're doing
        logger.info(f"Implementing revisions for {self.specialty} based on {len(str(revision_plan))} char plan")
        
        # If revision_plan is a dict, try to extract a string version
        if isinstance(revision_plan, dict):
            logger.info("Revision plan is a dictionary, extracting relevant content")
            # Try common keys that might contain the actual revisions
            for key in ["revisions", "revision_plan", "review", "project_review", "changes", "recommendations"]:
                if key in revision_plan and isinstance(revision_plan[key], str):
                    revision_plan = revision_plan[key]
                    logger.info(f"Using '{key}' from dictionary as revision plan")
                    break
            else:
                # If we didn't find a string value in expected keys, convert the whole dict to a string
                revision_plan = str(revision_plan)
                logger.warning("Converted entire revision_plan dict to string")
        
        system_prompt = f"""
        You are an expert {self.specialty.capitalize()} Engineer. Your task is to:
        1. Review the revision plan or project review
        2. Implement the required changes to the {self.specialty} components
        3. Document the changes made
        
        Focus on addressing the issues identified in the revision plan or project review.
        When providing code updates, include complete file content and use this format:
        ```language
        filepath/filename.ext
        // Updated code goes here
        ```
        """
        
        # Check for existing components to provide context
        component_context = ""
        try:
            # First, gather a general file structure for context
            structure_context = "# Project Structure\n"
            
            # Get main source directories
            src_dir = project_dir / "src"
            if src_dir.exists():
                structure_context += "\n## Source Directory\n"
                for item in src_dir.glob("*"):
                    if item.is_dir():
                        structure_context += f"- {item.name}/\n"
                        # List files in subdirectories if they exist
                        for subitem in item.glob("*"):
                            rel_path = subitem.relative_to(src_dir)
                            structure_context += f"  - {rel_path}\n"
                    else:
                        rel_path = item.relative_to(src_dir)
                        structure_context += f"- {rel_path}\n"
            
            # Now gather specialty-specific files
            component_dir = None
            if self.specialty == "backend":
                component_dir = project_dir / "src" / "server"
                if not component_dir.exists() or not any(component_dir.iterdir()):
                    alternate_dirs = [
                        project_dir / "src" / "backend",
                        project_dir / "backend",
                        project_dir / "api",
                        project_dir / "src" / "api"
                    ]
                    for alt_dir in alternate_dirs:
                        if alt_dir.exists() and any(alt_dir.iterdir()):
                            component_dir = alt_dir
                            break
            elif self.specialty == "frontend":
                component_dir = project_dir / "src" / "components"
                if not component_dir.exists() or not any(component_dir.iterdir()):
                    alternate_dirs = [
                        project_dir / "src" / "frontend",
                        project_dir / "frontend",
                        project_dir / "ui",
                        project_dir / "src" / "ui"
                    ]
                    for alt_dir in alternate_dirs:
                        if alt_dir.exists() and any(alt_dir.iterdir()):
                            component_dir = alt_dir
                            break
            elif self.specialty == "infrastructure":
                component_dir = project_dir / "infra"
                if not component_dir.exists() or not any(component_dir.iterdir()):
                    alternate_dirs = [
                        project_dir / "infrastructure",
                        project_dir / "deployment",
                        project_dir / "configs",
                        project_dir / "docker"
                    ]
                    for alt_dir in alternate_dirs:
                        if alt_dir.exists() and any(alt_dir.iterdir()):
                            component_dir = alt_dir
                            break
            
            if component_dir and component_dir.exists():
                component_context += f"\n\n# Existing {self.specialty.capitalize()} Components\n"
                # List files in the component directory
                for file_path in component_dir.glob("**/*"):
                    if file_path.is_file():
                        try:
                            with open(file_path, 'r') as f:
                                file_content = f.read()
                            rel_path = file_path.relative_to(project_dir)
                            component_context += f"\n## {rel_path}\n```\n{file_content}\n```\n"
                        except Exception as e:
                            logger.warning(f"Error reading {file_path}: {str(e)}")
            else:
                logger.warning(f"No component directory found for {self.specialty}")
                # Look for any files that might be relevant to this specialty
                component_context += f"\n\n# Files Possibly Related to {self.specialty.capitalize()}\n"
                found_files = False
                
                # Define file patterns that might be relevant to each specialty
                file_patterns = []
                if self.specialty == "backend":
                    file_patterns = ["*.py", "*.js", "server.js", "**/api/**", "**/*api*/**", "**/*server*/**"]
                elif self.specialty == "frontend":
                    file_patterns = ["*.html", "*.css", "*.jsx", "*.tsx", "*.vue", "**/*.component.*"]
                elif self.specialty == "infrastructure":
                    file_patterns = ["Dockerfile", "docker-compose.yml", "*.yaml", "*.yml", "*.tf", "*.config"]
                
                for pattern in file_patterns:
                    for file_path in project_dir.glob(pattern):
                        if file_path.is_file() and file_path.stat().st_size < 10000:  # Skip files >10KB
                            try:
                                with open(file_path, 'r') as f:
                                    file_content = f.read()
                                rel_path = file_path.relative_to(project_dir)
                                component_context += f"\n## {rel_path}\n```\n{file_content}\n```\n"
                                found_files = True
                            except Exception as e:
                                logger.warning(f"Error reading {file_path}: {str(e)}")
                
                if not found_files:
                    component_context += "\nNo relevant files found.\n"
        except Exception as e:
            logger.warning(f"Error gathering component context: {str(e)}")
            component_context = f"\nError gathering context: {str(e)}\n"
        
        prompt = f"""
        # Revision Information
        {revision_plan}
        
        {structure_context}
        
        {component_context}
        
        # Task
        Implement the required revisions for {self.specialty} components by:
        - Identifying revisions related to {self.specialty} components
        - For each revision:
          * Describe the implementation approach
          * Provide updated code with complete file content
          * Document the changes made
        
        Format your response as a structured revision implementation document with complete updated files.
        For each code file, use the format:
        ```language
        filepath/filename.ext
        // Updated code content
        ```
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate revisions using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Process and save the revisions output
        revisions_output = process_implementation_output(
            project_dir, 
            f"{self.specialty}/revisions", 
            response
        )
        
        # Structure the output
        revisions = {
            "timestamp": datetime.now().isoformat(),
            "engineer": self.name,
            "specialty": self.specialty,
            "revised_system": response,
            "revision_plan": revision_plan,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "saved_files": revisions_output["saved_files"]
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully implemented revisions for {self.specialty} components and saved to {project_dir / self.specialty / 'revisions'}"
        )
        
        return revisions
    
    def _fix_bugs(self, test_results: str, project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Fix bugs identified in test results."""
        system_prompt = f"""
        You are an expert {self.specialty.capitalize()} Engineer. Your task is to:
        1. Review the test results and identified bugs
        2. Fix the issues in the {self.specialty} components
        3. Document the fixes applied
        
        Focus on resolving all identified issues while maintaining code quality.
        When providing code fixes, include complete file content and use this format:
        ```language
        filepath/filename.ext
        // Fixed code goes here
        ```
        """
        
        prompt = f"""
        # Test Results
        {test_results}
        
        # Task
        Fix the identified bugs by:
        - Analyzing bugs related to {self.specialty} components
        - For each bug:
          * Describe the root cause
          * Provide the fix with complete file content
          * Explain how the fix resolves the issue
        
        Format your response as a structured bug fix document with complete fixed files.
        For each code file, use the format:
        ```language
        filepath/filename.ext
        // Fixed code content
        ```
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate bug fixes using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Process and save the bug fixes output
        fixes_output = process_implementation_output(
            project_dir, 
            f"{self.specialty}/fixes", 
            response
        )
        
        # Structure the output
        fixes = {
            "timestamp": datetime.now().isoformat(),
            "engineer": self.name,
            "specialty": self.specialty,
            "fixed_system": response,
            "test_results": test_results,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "saved_files": fixes_output["saved_files"]
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully fixed bugs in {self.specialty} components and saved to {project_dir / self.specialty / 'fixes'}"
        )
        
        return fixes
    
    def _integrate_components(self, components: Dict[str, Any], project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Integrate all components into a complete system."""
        backend_components = components.get("backend_components", "")
        frontend_components = components.get("frontend_components", "")
        infrastructure_components = components.get("infrastructure_components", "")
        
        system_prompt = """
        You are an expert Software Integration Engineer. Your task is to:
        1. Review all component implementations (backend, frontend, infrastructure)
        2. Integrate them into a cohesive system
        3. Document the integration process and configuration
        4. Provide instructions for deploying and running the system
        
        Focus on ensuring all components work together seamlessly.
        If you need to create or modify any configuration or connection files, use this format:
        ```language
        filepath/filename.ext
        // Integration code goes here
        ```
        """
        
        prompt = f"""
        # Component Implementations
        
        ## Backend Components
        {backend_components}
        
        ## Frontend Components
        {frontend_components}
        
        ## Infrastructure Components
        {infrastructure_components}
        
        # Task
        Integrate all components into a complete system by:
        - Describing how components interact with each other
        - Providing configuration for connecting components
        - Documenting the system startup sequence
        - Creating deployment instructions
        - Including a system verification checklist
        
        Format your response as a structured integration document.
        For any new or modified integration files, use the format:
        ```language
        filepath/filename.ext
        // Integration code content
        ```
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate integration document using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Save the integration document
        integration_path = project_dir / "integration.md"
        with open(integration_path, 'w') as f:
            f.write(response)
        
        # Extract and save any code blocks from the integration document
        saved_files = save_code_blocks_from_text(project_dir, "integration", response)
        
        # Structure the output
        integrated_system = {
            "timestamp": datetime.now().isoformat(),
            "engineer": self.name,
            "integrated_system": response,
            "backend_components": backend_components,
            "frontend_components": frontend_components,
            "infrastructure_components": infrastructure_components,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "integration_doc": str(integration_path),
            "saved_files": [str(path) for path in saved_files]
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully integrated all components into a complete system and saved to {integration_path}"
        )
        
        return integrated_system


class QAEngineerAgent(Agent):
    """Agent that tests software components and creates documentation."""
    
    def execute(self, task_input: Any) -> Any:
        """Test software components or create documentation.
        
        Args:
            task_input: A dictionary containing the integrated system or fixed system.
            
        Returns:
            A dictionary with test results or documentation.
        """
        agent_log(
            self.name,
            "execute",
            f"Testing or documenting system: {task_input}"
        )
        
        # Get the project directory from the input
        project_title = None
        project_dir_str = None
        
        if isinstance(task_input, dict):
            project_title = task_input.get("project_title", "Software Project")
            project_dir_str = task_input.get("project_dir", None)
        
            # Get the project directory
            if project_dir_str:
                project_dir = Path(project_dir_str)
            else:
                project_dir = get_project_directory(project_title)
            
            # Determine the task type based on input
            if "integrated_system" in task_input:
                # Handle the case where the integrated_system is the whole dictionary
                integrated_system = task_input.get("implementation", "") or task_input.get("integrated_system", "")
                if not integrated_system:
                    # If we still don't have a meaningful value, use the whole thing
                    integrated_system = str(task_input)
                return self._test_system(integrated_system, task_input, project_dir, project_title)
            elif "fixed_system" in task_input:
                fixed_system = task_input.get("fixed_system", "")
                return self._create_documentation(fixed_system, task_input, project_dir, project_title)
            # Handle input from engineer-1 during integration task
            elif "implementation" in task_input and task_input.get("specialty", "") == "backend":
                integrated_system = task_input.get("implementation", "")
                return self._test_system(integrated_system, task_input, project_dir, project_title)
        
        # Default error case if we get here
        agent_log(self.name, "error", "Unrecognized input format")
        
        # Try to create a meaningful project directory for logging the error
        if not project_title:
            project_title = "Unknown Project"
        if not project_dir_str:
            project_dir = get_project_directory(project_title)
        
        # Log the error to the agent file
        self.log_to_agent_file(
            project_dir=project_dir,
            action_type="error",
            input_summary="Unrecognized input format",
            output_summary="Failed to parse input for QA testing",
            details={"input_type": str(type(task_input))}
        )
        
        return {
            "status": "error",
            "message": "Unrecognized input format for QA engineer agent",
            "project_title": project_title,
            "project_dir": str(project_dir)
        }
    
    def _test_system(self, integrated_system: str, full_input: Dict[str, Any], project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Test the integrated system for bugs and issues."""
        system_prompt = """
        You are an expert Quality Assurance Engineer. Your task is to:
        1. Review the integrated system
        2. Design and execute test cases for all components
        3. Identify bugs, issues, and potential improvements
        4. Document the test results in detail
        
        Focus on finding functional issues, performance problems, and usability concerns.
        When providing test code, use this format:
        ```language
        tests/component/filename.ext
        // Test code goes here
        ```
        """
        
        prompt = f"""
        # Integrated System
        {integrated_system}
        
        # Task
        Test the integrated system by:
        - Creating a comprehensive test plan covering all components
        - For each component:
          * Define test cases (including edge cases)
          * Execute tests (simulated)
          * Document any issues found
        - Categorize issues by severity (critical, high, medium, low)
        - Provide recommendations for fixing each issue
        
        Format your response as a structured test report.
        Include actual test code files where appropriate, using the format:
        ```language
        tests/component/filename.ext
        // Test code content
        ```
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate test results using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Save the test results document
        test_results_path = project_dir / "tests" / "test_results.md"
        with open(test_results_path, 'w') as f:
            f.write(response)
        
        # Extract and save test code from the response
        saved_test_files = save_code_blocks_from_text(project_dir, "tests", response)
        
        # Structure the output
        test_results = {
            "timestamp": datetime.now().isoformat(),
            "qa_engineer": self.name,
            "test_results": response,
            "integrated_system": integrated_system,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "test_results_doc": str(test_results_path),
            "saved_test_files": [str(path) for path in saved_test_files]
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully tested the integrated system and saved results to {test_results_path}"
        )
        
        return test_results
    
    def _create_documentation(self, fixed_system: str, full_input: Dict[str, Any], project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Create documentation for the system."""
        # Extract additional context if available
        backend_components = full_input.get("backend_components", "")
        frontend_components = full_input.get("frontend_components", "")
        infrastructure_components = full_input.get("infrastructure_components", "")
        integrated_system = full_input.get("integrated_system", "")
        test_results = full_input.get("test_results", "")
        
        system_prompt = """
        You are an expert Technical Documentation Specialist. Your task is to:
        1. Review the fixed system and all available information
        2. Create comprehensive documentation for the system
        3. Include user guides, API documentation, and deployment instructions
        4. Ensure the documentation is clear, complete, and well-structured
        
        Focus on making the documentation useful for both users and developers.
        """
        
        prompt = f"""
        # System Information
        
        ## Fixed System
        {fixed_system}
        
        ## Backend Components
        {backend_components}
        
        ## Frontend Components
        {frontend_components}
        
        ## Infrastructure Components
        {infrastructure_components}
        
        ## Integrated System
        {integrated_system}
        
        ## Test Results
        {test_results}
        
        # Task
        Create comprehensive documentation including:
        - Overview and system architecture
        - User guide (installation, configuration, usage)
        - API documentation (endpoints, request/response formats)
        - Developer guide (codebase structure, contributing guidelines)
        - Deployment instructions
        - Troubleshooting guide
        
        Format your response as a structured documentation set.
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate documentation using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Split the documentation into separate files for different sections
        sections = [
            ("overview", "System Overview", r"# Overview|# System Overview"),
            ("user_guide", "User Guide", r"# User Guide"),
            ("api_documentation", "API Documentation", r"# API Documentation|# API Reference"),
            ("developer_guide", "Developer Guide", r"# Developer Guide|# Development Guide"),
            ("deployment", "Deployment Guide", r"# Deployment|# Deployment Guide|# Deployment Instructions"),
            ("troubleshooting", "Troubleshooting Guide", r"# Troubleshooting|# Troubleshooting Guide")
        ]
        
        # Create a main README
        readme_content = f"# {project_title} Documentation\n\n"
        readme_content += "## Documentation Sections\n\n"
        
        saved_docs = []
        for section_id, section_name, pattern in sections:
            # Try to find the section in the response
            match = re.search(f"({pattern}.*?)(?=# |$)", response, re.DOTALL | re.IGNORECASE)
            if match:
                section_content = match.group(1).strip()
                doc_path = save_documentation(project_dir, section_id, section_content)
                saved_docs.append(str(doc_path))
                readme_content += f"- [{section_name}]({os.path.basename(doc_path)})\n"
            else:
                readme_content += f"- {section_name} (Not available)\n"
        
        # Save the full documentation
        full_doc_path = project_dir / "docs" / "full_documentation.md"
        with open(full_doc_path, 'w') as f:
            f.write(response)
        saved_docs.append(str(full_doc_path))
        
        # Save the README
        readme_path = project_dir / "README.md"
        with open(readme_path, 'w') as f:
            f.write(readme_content)
        saved_docs.append(str(readme_path))
        
        # Structure the output
        documentation = {
            "timestamp": datetime.now().isoformat(),
            "qa_engineer": self.name,
            "documentation": response,
            "fixed_system": fixed_system,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "documentation_files": saved_docs,
            "readme_path": str(readme_path)
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully created system documentation and saved to {project_dir / 'docs'}"
        )
        
        return documentation


class ReviewerAgent(Agent):
    """Agent that reviews and evaluates the final project."""
    
    def execute(self, task_input: Any) -> Any:
        """Review the project against initial requirements.
        
        Args:
            task_input: A dictionary containing documentation or revised system.
            
        Returns:
            A dictionary with project review or final approval.
        """
        agent_log(
            self.name,
            "execute",
            f"Reviewing project: {str(task_input)}"
        )
        
        # Get the project directory from the input
        project_title = task_input.get("project_title", "Software Project")
        project_dir_str = task_input.get("project_dir", None)
        
        # Get the project directory
        if project_dir_str:
            project_dir = Path(project_dir_str)
        else:
            project_dir = get_project_directory(project_title)
        
        # Determine if this is initial review or final approval
        if "documentation" in task_input:
            documentation = task_input.get("documentation", "")
            return self._review_project(documentation, task_input, project_dir, project_title)
        elif "revised_system" in task_input:
            revised_system = task_input.get("revised_system", "")
            return self._final_approval(revised_system, task_input, project_dir, project_title)
        else:
            agent_log(self.name, "error", "Unrecognized input format")
            return {
                "status": "error",
                "message": "Unrecognized input format for reviewer agent"
            }
    
    def _review_project(self, documentation: str, full_input: Dict[str, Any], project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Review the project against initial requirements."""
        # Try to find original requirements from the task chain
        original_requirements = ""
        for key in full_input:
            if key == "original_requirements":
                original_requirements = full_input[key]
                break
        
        system_prompt = """
        You are an expert Project Reviewer. Your task is to:
        1. Review the project documentation against the initial requirements
        2. Evaluate the project's completeness, quality, and adherence to requirements
        3. Identify any gaps, issues, or areas for improvement
        4. Provide a detailed assessment of the project
        
        Focus on being thorough and critical to ensure the project meets all requirements.
        """
        
        prompt = f"""
        # Project Documentation
        {documentation}
        
        # Original Requirements
        {original_requirements}
        
        # Task
        Review the project by:
        - Assessing how well it meets each original requirement
        - Evaluating the overall architecture and implementation quality
        - Identifying any gaps or missing features
        - Noting any potential issues or concerns
        - Suggesting improvements or enhancements
        - Providing an overall assessment (acceptable, needs minor revisions, needs major revisions)
        
        Format your response as a structured review document.
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate review using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Save the review document
        review_path = project_dir / "docs" / "project_review.md"
        with open(review_path, 'w') as f:
            f.write(response)
        
        # Structure the output
        review = {
            "timestamp": datetime.now().isoformat(),
            "reviewer": self.name,
            "project_review": response,
            "documentation": documentation,
            "original_requirements": original_requirements,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "review_path": str(review_path)
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully reviewed the project and saved review to {review_path}"
        )
        
        return review
    
    def _final_approval(self, revised_system: str, full_input: Dict[str, Any], project_dir: Path, project_title: str) -> Dict[str, Any]:
        """Final review of the project after revisions."""
        # Try to find original requirements and previous review
        original_requirements = ""
        project_review = ""
        for key in full_input:
            if key == "original_requirements":
                original_requirements = full_input[key]
            elif key == "project_review":
                project_review = full_input[key]
        
        system_prompt = """
        You are an expert Project Reviewer conducting a final assessment. Your task is to:
        1. Review the revised system against the original project review feedback
        2. Determine if all issues and gaps have been addressed
        3. Make a final approval decision on the project
        4. Provide a detailed assessment of the final state
        
        Focus on determining if the project now meets all requirements and is ready for delivery.
        """
        
        prompt = f"""
        # Revised System
        {revised_system}
        
        # Original Project Review
        {project_review}
        
        # Original Requirements
        {original_requirements}
        
        # Task
        Conduct a final review by:
        - Assessing how well the revisions address previous feedback
        - Verifying that all identified issues have been resolved
        - Evaluating if the project now meets all requirements
        - Making a final approval decision (approved, conditionally approved, rejected)
        - Providing a detailed justification for your decision
        
        Format your response as a structured final approval document.
        """
        
        # Get model client
        client = self.get_model_client()
        
        # Generate final approval using the model
        response = client.generate(prompt, system_prompt=system_prompt)
        
        # Save the final approval document
        approval_path = project_dir / "docs" / "final_approval.md"
        with open(approval_path, 'w') as f:
            f.write(response)
        
        # Structure the output
        final_approval = {
            "timestamp": datetime.now().isoformat(),
            "reviewer": self.name,
            "final_approval": response,
            "revised_system": revised_system,
            "project_review": project_review,
            "original_requirements": original_requirements,
            "project_title": project_title,
            "project_dir": str(project_dir),
            "approval_path": str(approval_path)
        }
        
        agent_log(
            self.name,
            "execute",
            f"Successfully completed final project review and saved to {approval_path}"
        )
        
        return final_approval 