"""MiMi: AI Tool for running Multi Agent Multi Model Projects."""

__version__ = "0.1.0" 